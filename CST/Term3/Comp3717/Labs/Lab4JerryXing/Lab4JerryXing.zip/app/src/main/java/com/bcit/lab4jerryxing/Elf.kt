package com.bcit.lab4jerryxing

/**
 * Elf minion
 */
class Elf : Minion() {
    override val race = "Elf"
    override val baseHealth = 2
    override val baseSpeed = 8
    override val backpackSize = 3
    override val catchphrase = "My arrows never miss!"
}
