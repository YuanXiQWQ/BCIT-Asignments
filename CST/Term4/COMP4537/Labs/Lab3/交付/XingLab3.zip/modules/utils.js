"use strict";

class Utils {
  /**
   * Returns the current date and time
   * @return {string}
   */
  static getDate() {
    return new Date().toString();
  }
}

module.exports = {Utils};
