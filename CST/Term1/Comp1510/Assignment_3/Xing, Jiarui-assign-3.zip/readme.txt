[Xing Jiarui], [A01354731], [SetD], [2024.4.10]

This assignment is [enter percent]% complete.


------------------------
Question one (Timesheet) status:

[complete or not complete]
[complete]

------------------------
Question two (Exponential) status:

[complete or not complete]
[complete]

------------------------
Question three (TestMIXChar) status:

[complete or not complete]
[complete]
