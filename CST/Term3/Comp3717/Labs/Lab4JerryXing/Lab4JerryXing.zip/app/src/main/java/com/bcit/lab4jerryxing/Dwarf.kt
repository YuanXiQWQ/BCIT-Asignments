package com.bcit.lab4jerryxing

/**
 * Dwarf minion
 */
class Dwarf : Minion() {
    override val race = "Dwarf"
    override val baseHealth = 8
    override val baseSpeed = 2
    override val backpackSize = 8
    override val catchphrase = "Wheres' me trusty ol hammer?"
}
